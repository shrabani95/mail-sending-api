var jsonObject={    
        "enviornment": "test",
        "paths":{
            "test":{
                "cashfreePayUrl":"https://test.cashfree.com/billpay/checkout/post/submit"
            },
            "prod":{
                "cashfreePayUrl":"https://www.cashfree.com/checkout/post/submit"
            }
        },
        "appIdSecretKey":{
            "test":{
                "appId":"67558561d3dc71360c3ef303585576",
                "secretKey":"bc78a0556c2151eabf477ba27f418ab9561a43b3" 
            },
            "prod":{
                "appId":"1136147eba59ad20e66649daba416311",
                "secretKey":"03902f6bb08637139dcfc0f9c9976dc408075cff" 
            }
        }
    
}
export default jsonObject;