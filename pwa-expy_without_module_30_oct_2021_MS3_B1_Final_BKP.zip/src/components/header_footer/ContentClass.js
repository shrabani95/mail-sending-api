import React, { Component } from 'react'

export default class ContentClass extends Component {
  render() {
    return (
      <>
        <div style={{margin:"300px"}}>
            <h2>Content</h2>
        </div>
      </>
    )
  }
}
