import React from 'react';

  // import FacebookLogin from 'react-facebook-login';
  // import InstagramLogin from 'react-instagram-login';

  class facebook extends React.Component {

    constructor(props) {
      super(props)
    
      this.state = {
         isloggedin:false,
      }
    }
    
    
 
    render() {

      
      return (
          <>
       
        
      </>
      )
    }
  }
 
  export default facebook;