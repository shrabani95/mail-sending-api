const Columns = [
    
     
    {
        Header: 'Name',
        accessor: 'BM_Name',
    },
    {
        Header: 'Email ID',
        accessor: 'BM_Email',
    },
    {
        Header: 'Service',
        accessor: 'DA_Title',
    },
    {
        Header: 'Price',
        accessor: 'BM_Purchase_Amt',
    },
    {
        Header: 'Message',
        accessor: 'BM_Instruction',
    },
    {
        Header: 'Status',
        accessor: 'Status',
    },
    {
        Header: 'File',
        accessor: 'BM_Content_Sent',
    },
    {
        Header: 'Action',
        accessor: '',
    },
    {
        Header: 'Date & Time',
        accessor: 'BM_Purchase_Date',
    },
    
];
