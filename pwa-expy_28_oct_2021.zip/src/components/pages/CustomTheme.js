import React, { Component } from 'react';


class CustomTheme extends Component {
    constructor(props) {
        super(props);

    }

   

    render() {
        return (
            <div>
                    
            </div>
        );
    }
}

CustomTheme.propTypes = {

};

export default CustomTheme;