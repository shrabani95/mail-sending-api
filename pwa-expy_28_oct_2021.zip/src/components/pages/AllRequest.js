import React, { Component } from 'react';


class AllRequest extends Component {
    constructor(props) {
        super(props);

    }

    

    render() {
        return (
            <div>
                
            </div>
        );
    }
}

AllRequest.propTypes = {

};

export default AllRequest;